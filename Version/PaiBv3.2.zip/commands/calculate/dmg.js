const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: 'dmg',
	aliases: ['dmgc', '데미지'],
	category: 'Calculate',
	description: 'Calculate dmg',
	utilisation: '{prefix}dmg [Number]',

	execute(client, message, args) {
		const msg = message;
		const cmd = msg.content;
		try {
			if (!msg.author.id == client.config.author)
				return msg.lineReply(
					`**[!] This command can only run by a PaiB Admin**`
				);

			if (!args[0]) {
				msg.lineReply(`**[!] Input Error**`);
			} else if (args[0]) {
				var a0 = args[0]; //최종공격력
				var a1 = args[1]; //스킬계수
				var a2 = args[2]; //피증총합
				var a3 = args[3]; //치피
				var a4 = args[4]; //증폭(1/1.5/2)
				var a5 = args[5]; //원마계수

				var t0 = Number(a0);
				var t1 = Number(a1 / 100);
				var t2 = Number(a2 / 100) + 1;
				var t3 = Number(a3 / 100);
				var t4 = Number(a4);
				var t5 = Number(a5 / 100) + 1;

				var pdmg = Math.round(t0 * t1 * t2).toLocaleString();
				var cdmg = Math.round(t0 * t1 * t2 * t3).toLocaleString();
				var epdmg = Math.round(t0 * t1 * t2 * t4 * t5).toLocaleString();
				var ecdmg = Math.round(t0 * t1 * t2 * t3 * t4 * t5).toLocaleString();

				console.log(
					`DMGINFO - | a0: ${a0} | a1: ${a1}% | a2: ${a2}% | a3: ${a3}% | a4: ${a4} | a5: ${a5}% |`
				);
				console.log(
					`DMGCAL - | t0: ${t0} | t1: ${t1} | t2: ${t2} | t3: ${t3} | t4: ${t4} | t5: ${t5} |`
				);

				msg.lineReply(
					'**데미지 계산기**\n```\n' +
						`기본 데미지: ${pdmg}\n원소 반응 기본 데미지: ${epdmg}\n치명타 데미지: ${cdmg}\n원소 반응 치명타 데미지: ${ecdmg}\n----------\n최종공격력: ${a0}\n스킬계수: ${a1}%\n피증총합: ${a2}%\n치피: ${a3}%\n증폭: ${a4}\n원마계수: ${a5}%` +
						'\n----------\n오차 범위: ±35%\n```'
				);
			}
		} catch (e) {
			console.log(e);
			message.reply(`\n에러: ${e}`);
			return;
		}
	}
};

/** 
* ====================
* 
* 최종공격력 = 캐릭기본공격력 + 무기 공격력 + 성유물 공격력 + 무기스킬 + 버프(공격력증가)
* 
* 피증총합 = 원소피해보너스 + 보너스 피해 증가 + 무기스킬 + 버프(피해증가)
* 
* 원마계수 = 증발, 융해, 감전, 초전도, 빙결
* 
* 증폭 = 1, 1.5, 2 (원소 부여 순서에 따라 다름)
*
* 몹방어력 = ??
* 
* --------------------
* 
* 물리데미지 = 최종공격력 * 스킬계수 * 피증총합 * 버프(데미지증가)
* 
* 원소데미지 = 최종공격력 * 스킬계수 * 피증총합 * 버프(데미지증가)
* 
* 물리치명타데미지 = 물리데미지 * 치피
* 
* 원소치명타데미지 = 원소데미지 * 치피
* 
* 치명타 기대 값 = 치확 * 치피
*
* 실제 타격 데미지 = 데미지 * 몹방어력
* 
* ====================
**/
const Discord = require('discord.js');
const client = new Discord.Client();
const rsI =
	'https://raw.githubusercontent.com/Rutheon/PaiB/main/File/Img/F8B17943-F71D-4598-8884-AC17B91B1156.png';

module.exports = {
	name: 'resin',
	aliases: ['rs', '레진'],
	category: 'Calculate',
	description: 'Calculate resin',
	utilisation: '{prefix}resin [1~160] [1~160]',

	execute(client, message, args) {
		const msg = message;
		const cmd = msg.content;
		const rsc = new Discord.MessageEmbed()
			.setTitle(`Resin Calculate`)
			.setColor('BLUE')
			.setThumbnail(rsI)
			.setTimestamp()
			.setFooter(
				message.author.tag,
				message.author.avatarURL({
					dynamic: true,
					format: 'jpg',
					size: 2048
				})
			);

		try {
			if (!args[0]) {
				msg.lineReply(
					'**[!] Input Error**\n```\n' + `_resin [0~160] [Max Resin]` + '\n```'
				);
			} else if (args[0]) {
				var inps = args[0];
				var inpf = args[1] || 160;
				if (isNaN(inps) || isNaN(inpf) || inps < 0 || inps > 161)
					return msg.lineReply(
						'**[!] Input Error**\n```\n' +
							`_resin [0~160] [Max Resin]` +
							'\n```'
					);
				var maxR = (Number(inpf) - Number(inps)) * 8;
				if (maxR <= 0)
					return msg.lineReply(
						'**Resin**\n```\n' +
							`이미 레진이 최대치에 도달하셨습니다.` +
							'\n```'
					);

				let hI = Math.floor(maxR / 60);
				let mI = maxR % 60;
				let min = mI;
				let hour = Math.floor(min / 60) + hI;
				//let hH = ('0' + hour).slice(-2);
				//let mM = ('0' + min).slice(-2);

				rsc.setDescription(
					'```\n' +
						`${hour}시간 ${min}분 뒤,\n레진이 [${inpf}]에 도달합니다.` +
						'\n```'
				);

				return msg.channel.send(rsc);
			}
		} catch (e) {
			console.log(e);
			message.reply(`\n에러: ${e}`);
			return;
		}
	}
};

const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: 'spcal',
	aliases: ['spc'],
	category: 'Calculate',
	description: 'Calculate special dmg',
	utilisation: '{prefix}spc [Number]',

	execute(client, message, args) {
		const msg = message;
		const cmd = msg.content;
		try {
			if (!msg.author.id == client.config.author)
				return msg.lineReply(`**[!] This command can only run by a PaiB Admin**`);

			if (!args[0]) {
				msg.lineReply(`**[!] Input Error**`);
			} else if (args[0]) {
				var hp = Number(args[0]);
				var atk = Number(args[1]);
				var heal = Number(args[2]);
				var w = Number(0.904);

				var p1 = Math.round(atk * 1.51 * w);
				var p2 = Math.round(atk * 2.37 * w);
				var e1 = Math.round(atk * 1.75 * w);
				var hb = Number((heal * 0.15) / 100);
				var qp1 = Math.round((atk + hp * (hb + 0.0774)) * 1.51 * w);
				var qp2 = Math.round((atk + hp * (hb + 0.108)) * 2.37 * w);

				console.log(
					`DMGINFO - | hp: ${hp} | atk: ${atk} | heal: ${heal}% | w: ${w}% |`
				);
				console.log(
					`DMGCAL - | p1: ${p1} | p2: ${p2} | e1: ${e1} | hb: ${hb} | qp1: ${qp1} | qp2: ${qp2} |`
				);

				msg.lineReply(
					'**코코미 데미지 계산기**\n```\n' +
						`\n평타(최대): ${p1.toLocaleString()}\n강공: ${p2.toLocaleString()}\nE: ${e1.toLocaleString()}\nQ평(최대): ${qp1.toLocaleString()}\nQ강공: ${qp2.toLocaleString()}` +
						'\n```'
				);
			}
		} catch (e) {
			console.log(e);
			message.reply(`\n에러: ${e}`);
			return;
		}
	}
};

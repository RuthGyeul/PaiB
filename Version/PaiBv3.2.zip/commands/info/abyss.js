const Discord = require('discord.js');
const client = new Discord.Client();
const abyI =
	'https://raw.githubusercontent.com/Rutheon/PaiB/main/File/Img/42640A42-84D8-4E21-A606-978F92D4EC64.png';

function abssC(msg, start, end, rs) {
	var one_day = 1000 * 60 * 60 * 24;
	let remaining = (end.getTime() - start.getTime()) / one_day;
	let days = Math.floor(remaining);
	let hours = (remaining - days) * 24;
	let minutes = Math.ceil((hours - Math.floor(hours)) * 60);
	hours = Math.floor(hours);

	const emd = new Discord.MessageEmbed()
		.setTitle(`${rs} Abyss`)
		.setColor('BLUE')
		.setThumbnail(abyI)
		.setDescription(
			'```\n' + `리셋까지 ${days}일 ${hours}시간 ${minutes}분 남음` + '\n```'
		);

	return msg.channel.send(emd);
}

module.exports = {
	name: 'abyss',
	aliases: ['abs', '나선', '연월', '나선비경', '연월비경'],
	category: 'Info',
	description: 'Time until abyss reset',
	utilisation: '{prefix}abyss [NA]',

	execute(client, message, args) {
		const msg = message;
		const cmd = msg.content;

    return msg.lineReply('기능 종료됨');
    
		var today = new Date();
		var na = new Date(
			today.getFullYear(),
			today.getMonth(),
			today.getDay() + 19,
			today.getHours() - 4,
			today.getMinutes(),
			today.getSeconds()
		);
		var asia = new Date(
			today.getFullYear(),
			today.getMonth(),
			today.getDay() + 19,
			today.getHours() + 9,
			today.getMinutes(),
			today.getSeconds()
		);

		try {
			if (!args[0]) {
				return msg.lineReply(
					'```\n' + `Pleas type the region.\n_Abyss [NA/ASIA]` + '\n```'
				);
			} else if (args[0] == 'NA') {
				var rs = 'NA';
				var td = na;
				var abyss1 = new Date(
					today.getFullYear(),
					today.getMonth() + 1,
					1,
					8,
					0,
					0
				);
				var abyss2 = new Date(
					today.getFullYear(),
					today.getMonth(),
					16,
					8,
					0,
					0
				);
			} else if (args[0] == 'ASIA') {
				var rs = 'ASIA';
				var td = asia;
				var abyss1 = new Date(
					today.getFullYear(),
					today.getMonth() + 1,
					1,
					5,
					0,
					0
				);
				var abyss2 = new Date(
					today.getFullYear(),
					today.getMonth(),
					16,
					5,
					0,
					0
				);
			} else {
				return msg.lineReply(
					'```\n' + `Pleas type the region.\n_Abyss [NA/ASIA]` + '\n```'
				);
			}

			if (td.getDate() <= abyss2.getDate()) {
				abssC(msg, td, abyss2, rs);
			} else {
				abssC(msg, td, abyss1, rs);
			}
		} catch (e) {
			console.log(e);
			message.reply(`\n에러: ${e}`);
			return;
		}
	}
};

const Discord = require('discord.js');
const client = new Discord.Client();
const nowChar =
	'https://raw.githubusercontent.com/Rutheon/PaiB/main/File/Img/Chargif/IMG_0163.gif';

function bannerC(msg, start, end, rs) {
	var one_day = 1000 * 60 * 60 * 24;
	let remaining = (end.getTime() - start.getTime()) / one_day;
	let days = Math.floor(remaining);
	let hours = (remaining - days) * 24;
	let minutes = Math.ceil((hours - Math.floor(hours)) * 60);
	hours = Math.floor(hours);

	const emd = new Discord.MessageEmbed()
		.setTitle(`${rs} Banner : 진주의 지혜`)
		.setThumbnail(nowChar)
		.setColor('BLUE')
		.setDescription(
			'```\n' + `종료까지 ${days}일 ${hours}시간 ${minutes}분 남음` + '\n```'
		)
		.setFooter(
			`산고노미야 코코미 - "전장은 변화무쌍하기에 모든 걸 완벽하게 고려해야만 백전불태할 수 있어."`
		);

	return msg.channel.send(emd);
}

module.exports = {
	name: 'bannerR',
	aliases: ['breset', 'bannerreset', '배너', '배너리셋', 'bnr', 'banner'],
	category: 'Info',
	description: 'Show remaining time of current banner',
	utilisation: '{prefix}breset',

	execute(client, message, args) {
		const msg = message;
		const cmd = msg.content;

    return msg.lineReply('기능 종료됨');
    
		var today = new Date();
		var na = new Date(
			today.getFullYear(),
			today.getMonth(),
			today.getDay() + 19,
			today.getHours() - 4,
			today.getMinutes(),
			today.getSeconds()
		);
		var asia = new Date(
			today.getFullYear(),
			today.getMonth(),
			today.getDay() + 19,
			today.getHours() + 9,
			today.getMinutes(),
			today.getSeconds()
		);
		try {
			if (!args[0]) {
				return msg.lineReply(
					'```\n' + `Pleas type the region.\n_Banner [NA/ASIA]` + '\n```'
				);
			} else if (args[0] == 'NA') {
				var rs = 'NA';
				var td = na;
				var banner = new Date(today.getFullYear(), 9, 12, 15, 59, 0);
				//미동부가 4시간 느림
			} else if (args[0] == 'ASIA') {
				var rs = 'ASIA';
				var td = asia;
				var banner = new Date(today.getFullYear(), 9, 12, 15, 59, 0);
				//한국이 9시간 빠름
			} else {
				return msg.lineReply(
					'```\n' + `Pleas type the region.\n_Banner [NA/ASIA]` + '\n```'
				);
			}
			console.log(td);
			console.log(banner);

			bannerC(msg, td, banner, rs);
		} catch (e) {
			console.log(e);
			message.reply(`\n에러: ${e}`);
			return;
		}
	}
};

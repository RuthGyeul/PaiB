module.exports = {
	author: '667108076561629205',
	token: 'ODU2OTcyODQ1NzI0MDc0MDA0.YNI0KA.3oGTTBUFPGHfU-2PbXhXMnhjsME',
	prefix: '_',
	activity: ['Genshin Impact', '일어나, 일퀘해야지?', '_help', '_cb']
};

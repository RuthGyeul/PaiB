require('dotenv').config();
require('discord-reply');
const Discord = require('discord.js');
const fs = require('fs');
const keepAlive = require('./server.js');
const client = new Discord.Client();

/*---- Config ----*/
client.config = require('./configs/config.js');
client.commands = new Discord.Collection();
const TOKEN = client.config.token;

/*---- Event ----*/
const events = fs.readdirSync('./events').filter(file => file.endsWith('.js'));

for (const file of events) {
	console.log(`Loaded event: ${file}`);
	const event = require(`./events/${file}`);
	client.on(file.split('.')[0], event.bind(null, client));
}

/*---- Commands ----*/
fs.readdirSync('./commands').forEach(dirs => {
	const commands = fs
		.readdirSync(`./commands/${dirs}`)
		.filter(files => files.endsWith('.js'));

	for (const file of commands) {
		const command = require(`./commands/${dirs}/${file}`);
		console.log(`Loaded command: ${file}`);
		client.commands.set(command.name.toLowerCase(), command);
	}
});

client.on('message', message => {
	const msg = message;
	const cmd = msg.content;
	const ath = msg.author.id;
	if (cmd == '!d bump') {
		msg.lineReply('120분 뒤에 멘션 알림이 갑니다.').then(msg => {
			setTimeout(function() {
				msg.channel.send(`<@${ath}> 120분이 지났습니다!`);
			}, 7200000);
		});
	}
});

/*---- Server ----*/
keepAlive();
client.login(TOKEN);

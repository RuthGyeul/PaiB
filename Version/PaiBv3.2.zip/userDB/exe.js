const Discord = require('discord.js');
const fs = require('fs');
const client = new Discord.Client();

/*---- Edit Json File ----*/
function userDBset(message, cmd, uID) {
	var databaseU = `./userDB/${uID}.json`;
	let rawdata = fs.readFileSync(`./userDB/${uID}.json`);
	const uDB = JSON.parse(rawdata);

	if (cmd == 'set') {
		uDB = {
			info: {
				uNM: '',
				uID: ''
			},

			binfo: {
				pulls: [0, 0, 0],
				pity_5: [0, 0, 0],
				pity_4: [0, 0, 0],
				featured_4: [false, false],
				featured_5: [false, false],
				counter: [0, 0],
				item: []
			},

			summery: {
				pullsp: '',
				pull5: '',
				pull4: ''
			},

			item: {
				ci: [],
				wi: [],
				si: []
			}
		};
	}

	// save the database
	let data = JSON.stringify(uDB, null, 2);
	fs.writeFileSync(uDB, data);

	message.reply('User DB file has been updated!');
}

module.exports = {
	name: 'ujson',
	aliases: ['ujfile', 'ufile'],
	category: 'Info',
	description: 'Edit user json fIle',
	utilisation: '{prefix}ujson [userID] [Type1] [Type2] [Type3]',

	execute(client, message, args) {
		const msg = message;
		const cmd = msg.content;
		const prefix = client.config.prefix;
		try {
			if (msg.author.id != client.config.author)
				return msg.reply('Only Admin can run this command');
			if (!args[1])
				return msg.reply(
					`Wrong Input!\n${prefix}ujson [userID] [Type1] [Type2] [Type3]`
				);
			if (args[1]) {
				var uid = args[0];
				var co = args[1];
				var t1 = args[2];
				var t2 = args[3];
			}
			userDBset(msg, co, uid);
		} catch (e) {
			console.log(e);
			message.reply(`\n에러: ${e}`);
			return;
		}
	}
};
